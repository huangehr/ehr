package com.yihu.ehr.service.resource.stage2;

/**
 * 档案资源主记录。
 *
 * @author Sand
 * @created 2016.05.16 15:51
 */
public class MasterRecord extends ResourceRecord {

}
