package com.yihu.ehr.config;

/**
 * @author Sand
 * @created 2016.05.27 15:21
 */
public class MetricNames {
    public final static String ResourceJob = "svr-pack-resolve.PackageResourceJob";
}
