package com.yihu.ehr.standard.dispatch.service;

import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @author lincl
 * @version 1.0
 * @created 2016.3.2
 */
public interface XDispatchLogRepository extends PagingAndSortingRepository<DispatchLog, String> {



}
