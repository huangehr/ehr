package com.yihu.ehr.standard.datasets.service;

/**
 * 数据集实现类. ID与版本联合起来表示一个主键。此数据集用于表示一个已经版本好的对象。
 *
 * @author Sand
 * @version 1.0
 * @created 30-6月-2015 16:19:03
 */

public class DataSet extends BaseDataSet {

}