package com.yihu.ehr.standard.datasets.service;


/**
 * 数据元类.,  作为初始化版本实体的模版
 * @author lincl
 * @version 1.0
 * @created 2016.2.22
 */
public class MetaData extends BaseMetaData {


}