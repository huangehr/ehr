package com.yihu.ehr.standard.document.service;

/**
 * @author AndyCai
 * @version 1.0
 * @created 01-9月-2015 17:08:41
 */
public class CDADataSetRelationship extends BaseCDADataSetRelationship {

}