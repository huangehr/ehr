package com.yihu.ehr.standard.dict.service;


/**
 * 字典 , 作为动态实体模版。
 * @author lincl
 * @version 1.0
 * @created 2016.2.22
 */
public class Dict extends BaseDict {

}