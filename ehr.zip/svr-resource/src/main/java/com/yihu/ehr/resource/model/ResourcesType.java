package com.yihu.ehr.resource.model;

/**
 * Created by hzp on 2016/04/22.
 */
public class ResourcesType {

    public static final String HBASE_SINGLE_CORE = "1";
    public static final String HBASE_MULTI_CORE = "2";
    public static final String HBASE_SOLR = "3";
    public static final String RS_ETL = "4";
    public static final String RS_CONFIG = "5";
    public static final String RS_DICT = "6";

}




