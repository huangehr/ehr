package com.yihu.ehr.resource.model;

/**
 * Created by hzp on 2016/04/22.
 */
public class ResourcesInterface {

    public static final String EHR_CENTER = "getEhrCenter";
    public static final String EHR_CENTER_SUB = "getEhrCenterSub";
    public static final String Mysql = "getMysqlData";
    public static final String RS_ETL = "4";
    public static final String RS_CONFIG = "5";
    public static final String RS_DICT = "6";

}




